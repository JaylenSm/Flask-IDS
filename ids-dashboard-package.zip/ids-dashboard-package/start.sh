#!/bin/sh
echo "[+] Starting Flask Web Server..."
python3 webserver/app.py &

echo "[+] Starting IDS..."
python3 ids_engine.py &

echo "[+] Starting Dashboard Generator..."
python3 dashboard.py