from flask import Flask, render_template, request, redirect, abort
import logging
import os

app = Flask(__name__)

logging.basicConfig(filename='logs/access.log', level=logging.INFO, format='%(asctime)s %(message)s')

@app.route('/')
def main():
    logging.info("Visited /main from %s", request.remote_addr)
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    logging.info("Accessed /login from %s with method %s", request.remote_addr, request.method)
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        logging.info("Login attempt from %s: username=%s", request.remote_addr, username)
    return render_template('login.html')

@app.route('/admin')
def admin():
    logging.info("Accessed /admin from %s", request.remote_addr)
    abort(403)

@app.route('/forbidden')
def forbidden():
    logging.info("Accessed /forbidden from %s", request.remote_addr)
    abort(403)

@app.route('/dashboard')
def dashboard_view():
    alerts_path = os.path.join("logs", "alerts.log")
    try:
        with open(alerts_path, "r") as f:
            alert_lines = [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        alert_lines = ["No alerts logged yet."]
    return render_template("dashboard.html", alerts=alert_lines)

@app.errorhandler(403)
def forbidden_error(e):
    return render_template('403.html'), 403

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000)