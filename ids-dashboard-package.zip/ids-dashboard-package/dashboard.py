# Secure Flask dashboard to generate static dashboard.html from IDS logs
#Jinja2 imported from the flask module (render_template_string) to allow safe rendering of code present in logs as text
from flask import Flask, render_template_string
import os
import re
import html
import time

app = Flask(__name__)

ALERT_LOG_PATH = "logs/alerts.log"
OUTPUT_PATH = os.path.join("webserver", "static", "dashboard.html")

ALERT_PATTERN = re.compile(
    r"\[(.*?)\] Suspicious activity detected \((\w+).*?:\):\n\s+(.*)", re.MULTILINE
)

TEMPLATE = """<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>IDS Alert Dashboard</title>
    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css\" rel=\"stylesheet\">
    <meta http-equiv=\"refresh\" content=\"10\">
</head>
<body class=\"bg-light\">
<div class=\"container py-4\">
    <h2 class=\"mb-4 text-center\">Intrusion Detection Alerts</h2>
    <table class=\"table table-bordered table-hover bg-white shadow-sm\">
        <thead class=\"table-dark\">
            <tr>
                <th scope=\"col\">Timestamp</th>
                <th scope=\"col\">Severity</th>
                <th scope=\"col\">Alert Message</th>
            </tr>
        </thead>
        <tbody>
            {% for alert in alerts %}
            <tr class=\"{% if alert.severity == 'High' %}table-danger{% elif alert.severity == 'Medium' %}table-warning{% else %}table-light{% endif %}\">
                <td>{{ alert.timestamp | e }}</td>
                <td><strong>{{ alert.severity | e }}</strong></td>
                <td>{{ alert.message | e }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
</body>
</html>
"""

def parse_alerts():
    if not os.path.exists(ALERT_LOG_PATH):
        return []

    with open(ALERT_LOG_PATH, 'r') as f:
        contents = f.read()

    alerts = []
    matches = ALERT_PATTERN.findall(contents)
    for timestamp, severity, message in matches:
        alerts.append({
            "timestamp": html.escape(timestamp.strip()),
            "severity": html.escape(severity.strip().capitalize()),
            "message": html.escape(message.strip())
        })
    return alerts

def generate_dashboard():
    alerts = parse_alerts()
    with app.app_context():
        rendered = render_template_string(TEMPLATE, alerts=alerts)
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w") as f:
        f.write(rendered)
    print("[+] Dashboard updated.")

if __name__ == "__main__":
    while True:
        generate_dashboard()
        time.sleep(10)
