import time
import os
import re
from datetime import datetime

# Regex to remove ANSI escape sequences
ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

def clean_line(line):
    return ansi_escape.sub('', line).lower()

def tail_f(file_path):
    with open(file_path, 'r') as file:
        file.seek(0, 2)
        while True:
            line = file.readline()
            if not line:
                time.sleep(0.1)
                continue
            yield line

def load_signatures(filename):
    patterns = []
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or '|' not in line:
                continue
            pattern, severity = map(str.strip, line.split('|', 1))
            if pattern:
                patterns.append((pattern.lower(), severity.upper()))
    return patterns

def detect_suspicious_activity(line, patterns):
    clean = clean_line(line)
    for pat, severity in patterns:
        if pat in clean:
            print(f"[DEBUG] Pattern matched: '{pat}' with severity '{severity}'")
            return pat, severity
    return None, None

def log_alert(line, pattern, severity):
    alert_log_path = "logs/alerts.log"
    os.makedirs(os.path.dirname(alert_log_path), exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(alert_log_path, "a") as alert_log:
        alert_log.write(f"[{timestamp}] Suspicious activity detected ({severity.upper()} - matched: {pattern}):\n    {line.strip()}\n")

if __name__ == "__main__":
    patterns = load_signatures("suspicious_patterns.txt")
    print(f"[+] IDS started. Loaded {len(patterns)} patterns.")
    for log_line in tail_f("logs/access.log"):
        print(f"[DEBUG] Checking line: {log_line.strip()}")
        pattern, severity = detect_suspicious_activity(log_line, patterns)
        if pattern:
            print("[!] Suspicious activity detected!")
            log_alert(log_line, pattern, severity)